package EjemploColaCircular;

public class ColaCircular {

    int iFrente=-1;
    int iFinal=-1;
    int elementoscola[];
    int max=5;

    public ColaCircular(){
        elementoscola=new int [max];
    }
    public boolean Llena(){
        if(iFinal==max-1 && iFrente==0 || iFinal+1==iFrente){
            return true;
        }
        else{
            return false;
        }
    }
    public boolean Vacia(){
        if(iFinal==-1 && iFrente==0){
            return true;
        }
        else{
            return false;
        }
    }
    public void Insertar(int dato){

        if(Llena()==true){
            System.out.print("Overflow \n");
        }
        else{

            if(iFinal==max-1 && iFinal>0){
                iFinal=0;
                elementoscola[iFinal]=dato;
            }
            else{
                iFinal++;
                elementoscola[iFinal]=dato;
                iFrente=0;
            }
            
        }
    }
    public int Retirar(){
        int aux=0;
        if(Vacia()==true){
            System.out.print("Empty \n");
        }
        else{
            elementoscola[iFrente]=aux;
            if(iFrente==iFinal){
                iFrente=-1;
                iFinal=-1;
            }
            else{
                iFrente++;
            }
        }
        return aux;
    }
    public void ImprimeCola(){
        for(int iCont=0; iCont<elementoscola.length; iCont++){
            System.out.println("Contenido: "+elementoscola[iCont]);
        }
    }
}
