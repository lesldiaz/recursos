
package EjemploColaCircular;
import java.io.*;
public class Main {

    public static void main(String[] args)throws IOException {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String sIngreso;

        ColaCircular clcircular=new ColaCircular();

        int iOpcion=0;
        int iNum;

        while(iOpcion<=3){
        System.out.println("Ingrese opcion: \n"+
                "1.-Insertar \n" +
                "2.-Eliminar \n" +
                "3.-Mostrar contenido \n" +
                "4.-Salir ");
        sIngreso=br.readLine();
        iOpcion=Integer.parseInt(sIngreso);

        if(iOpcion==1){
            System.out.println("Ingresa dato: ");
            sIngreso=br.readLine();
            iNum=Integer.parseInt(sIngreso);
            clcircular.Insertar(iNum);
        }
        if(iOpcion==2){
            clcircular.Retirar();
        }
        if(iOpcion==3){
            clcircular.ImprimeCola();
        }
        }
    }
}
