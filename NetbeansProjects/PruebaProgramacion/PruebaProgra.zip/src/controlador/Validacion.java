/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import vista.Ventana;

/**
 *
 * @author USRBET
 */
public class Validacion {
    
    public boolean verificarCedula(String cedula){
        int total=0,tamanoLongitudCedula=10,numeroProvincias=24,tercerDigito=6;
        int [] coeficientes = {2,1,2,1,2,1,2,1,2};
        if(cedula.matches("[0-9]*")&& cedula.length()==tamanoLongitudCedula){
            int provincia= Integer.parseInt(cedula.charAt(0) + "" + cedula.charAt(1));
            int digitoTres = Integer.parseInt(cedula.charAt(2) + "");
            
            if( provincia>0 && provincia<=numeroProvincias && digitoTres<tercerDigito){
                int digitoVerificadorRecibido = Integer.parseInt(cedula.charAt(9)+ "");
                for(int i=0;i<coeficientes.length;i++){
                    int valor = Integer.parseInt(coeficientes[i] + "") * Integer.parseInt(cedula.charAt(i)+ "");
                    total = valor>=10? total + (valor-9) : total + valor;
                }
                int digitoVerificadorObtenido = total >= 10 ? (total % 10) != 0 ? 10 - (total % 10) : (total % 10) : total;
                
                if(digitoVerificadorObtenido == digitoVerificadorRecibido){
                    return true;
                }
            }
            return false;
        }
    return false;
    }
    
     public void copiarImg(BufferedImage bimage,String nombrecopia) { // buffered imagen es un almacenamiento de algo se guarda en un espacio de memoria buffer contenedor pequeño donde puedo almacenar cosas
        // ctrl + c
        ColorModel cm = bimage.getColorModel();
        //OBTENGO el color de la imagen, esa imagen tiene datos: pixel RGB : 0 a 255 a cada pizel, obtenemos todo el modelo de ese pixel obtengo todo el modelo rgb
        boolean alpha = cm.isAlphaPremultiplied(); //es un boolean y nos indica si la imagen es editada, nos sirve para mantener la edicion de la imagen
        WritableRaster raster = bimage.copyData(null); /// obtener los DATOS escritos sobre la imagen
        //arcivo de copia ctrl + v
        BufferedImage copia = new BufferedImage(cm,raster, alpha, null);
        // buscar la ruta de la imagen, ruta para guardar
        File guardarimagen = new File("/src/imagenes", nombrecopia);//nombrecopia es el nombre de la misma imagen
        try {
            ImageIO.write(copia,"jpg", guardarimagen);
        } catch (IOException ex) { // no se pueda leer escribir, imagen protegida, no encuetra direccion
            Logger.getLogger(Ventana.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
