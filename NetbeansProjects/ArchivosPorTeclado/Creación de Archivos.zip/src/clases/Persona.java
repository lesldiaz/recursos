/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author USRBET
 */
public class Persona {

    private String nombres, apellidos, id, fechanacimiento;

    public Persona(String nombres, String apellidos, String id, String fechanacimiento) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.id = id;
        this.fechanacimiento = fechanacimiento;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(String fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public int CalcularEdad(String fechanacimiento) {
        int edad; //declarar la variable
        edad = 0; //darle un vlor inicial de la variable

        return (edad);

    }

    public Persona() {

    }
}
